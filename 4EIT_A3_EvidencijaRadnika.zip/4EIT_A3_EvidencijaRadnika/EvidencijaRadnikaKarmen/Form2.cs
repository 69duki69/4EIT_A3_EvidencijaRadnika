﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EvidencijaRadnikaKarmen
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-MN94AM8\SQLEXPRESS;Initial Catalog=EIT_A03_EvidencijaRadnika;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;
        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private void PuniGridChart()
        {

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            //cmd.Parameters.AddWithValue("@Kategorija", SqlDbType.VarChar).Value = comboKategorijaChart.Text.ToString();
            //cmd.Parameters.AddWithValue("@VrednostOD", SqlDbType.VarChar).Value = numericVrednostOD.Value.ToString();
            //cmd.Parameters.AddWithValue("@VrednostDO", SqlDbType.VarChar).Value = numericVrednostDO.Value.ToString();

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "GodinaProjekta";
            chart1.Series["Series1"].YValueMembers = "BrPROJ";
            chart1.Series["Series1"].YValueMembers = "BrRadnika";
            chart1.Titles.Add("PRIMER CHART");
            

            Kon.Close();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            PuniGridChart();
            chart1.Titles.Clear();
        }
    }
}
